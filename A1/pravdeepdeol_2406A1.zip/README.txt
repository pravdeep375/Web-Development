Author:     Pravdeep Deol
            101007603
            pravdeepdeol@cmail.com

Version:    Node v8.11.4
            Windows 10 Machine
            Chrome Browser

Install:    No NPM modules used

Launch:     node assignment1Server.js

Testing:    Visit http://localhost:3000/assignment1.html

issues:     One issue is have not immplemented transpose operation for the flat semitones (Bb,Db,Eb,Gb,Ab).
            All other requirements are met