Author:     Pravdeep Deol
            101007603
            pravdeepdeol@cmail.com

Version:    Node v8.11.4
            Windows 10 Machine
            Chrome Browser

Install:    No NPM modules used

Launch:     node assignment2Server.js

Testing:    Visit http://localhost:3000/assignment2.html

issues:     
            Ongoing issues:
                - spacing on some longer chords overlap other chords
                - when placing chords near or at the end of the line causes that line and the next to merge